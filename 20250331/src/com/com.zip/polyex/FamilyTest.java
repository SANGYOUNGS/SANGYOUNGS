package com.polyex;

public class FamilyTest {

	public static void main(String[] args) {
		
		// 서브 클래스 인스턴스 생성
		SubTest ob1 = new SubTest();
		System.out.println("ob1.b : " +  ob1.b);
		
		//업 캐스팅 
		SuperTest ob2 = ob1;
		System.out.println("ob2.b : " + ob2.b
				);
	}

}
