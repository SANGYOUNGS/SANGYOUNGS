package com.polyex;

public class ParentEx {
	
	int foo =5;
	
	public int getNumber(int a) {
		return a+1;
	}
}
